import React from "react"
import Die from "./die"
import "./style.css";
import {nanoid} from "nanoid"
import Confetti from "react-confetti";
function App() {
  const [x,setx]=React.useState(0);
  const [t]=React.useState(new Date().getTime());
  const [dce,setdce]=React.useState(Dicerand())
  const [Tenzy,setTenzy]=React.useState(false);
  React.useEffect(()=>{
    const con1=dce.every(die=>die.isHeld)
    const val1=dce[0].value
    const con2=dce.every(die=>die.value===val1)
    
if(con1 && con2)
{setTenzy(true);
  console.log("You won");
}
  },[dce])
  function add()
    {setx(x+1);}
  function generatenum()
  {
    return {value:Math.ceil(Math.random()*6),isHeld:false,id:nanoid()}
  }
  function Dicerand(){
    const dicearr=[]
    for(let i=0;i<10;i++)
    dicearr.push(generatenum())
    return dicearr
  }
  function holdDice(id){
    setdce(olddice=>olddice.map
      (dice =>{return dice.id===id ? {...dice,isHeld:!dice.isHeld}:dice}))
    }
  function rollDice()
  {
    setdce(olddice=>olddice.map(die=> {return die.isHeld ? die :generatenum()}))
    add();
  }
  const diceele=dce.map(dice=><Die key={dice.id} value={dice.value} isHeld={dice.isHeld} id={dice.id} holdDice={()=>holdDice(dice.id)}/>)
  return (
    <center>
    <main> 
      {Tenzy && <Confetti/>}
      <h1 style={{'fontSize':'40px','margin':'5px','marginBottom':'10px'}}>TENZIES</h1>
    <b style={{'marginBottom':'10px'}}>Roll Dices till all are same.<br></br>Click each die to freeze current value. </b>
    <div className="dice-container">
      {diceele}
         </div>
         
         <button className="rollDice" onClick={rollDice}> {Tenzy ?"Refresh for New Game":"Roll"}</button>
         {Tenzy && (<><h2>You Won!</h2>
         <b>Number of times Dice rolled : {x}<br/></b>
         <b>Time taken : {true?Math.round((new Date().getTime()-t)/1000,1).toFixed(1):0} seconds !</b></>)}
    </main>
    </center>

);
}

export default App;
